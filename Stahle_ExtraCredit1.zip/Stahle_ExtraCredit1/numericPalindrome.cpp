//****************************************************************************************************
//
//		File:					NumericPalindrome.cpp
//
//		Student:				Chris Stahle
//
//		Assignment:	 			Program  # Extra Credit 1
//
//		Course Name:			Data Structures II
//
//		Course Number:			COSC 3050 - 01
//
//		Due:					May 5, 2016
//
//
//		This program uses a recursive function to determine if a user's numerical input is a 
//		palindrome or not.
//
//****************************************************************************************************
#include <iostream>
#include <iomanip>
#include <cmath> //for pow()
using namespace std;
//****************************************************************************************************
bool isPalindromeFunction(int input, int numDigits);
//****************************************************************************************************
int main()
{
	int input = 0;
	int numDigits = 0;
	bool quit = true; 

	while (quit)
	{
		cout << "Enter a numerical expression that you think might be a palindrome:\n";
		cin >> input;
		while (input)
		{
			input /= 10;
			numDigits++;
		}
		if (isPalindromeFunction(input, numDigits))
		{
			cout << "That number is a palindrome." << endl;
		}
		else
		{
			cout << "That number is not a palindrome." << endl;
		}
		cout << "Enter another expression? 1 for Yes, 0 for No:  \n";
		cin >> quit;
	}
	return 0;
}
//****************************************************************************************************
bool isPalindromeFunction(int input, int numDigits)
{
	int firstDigit = 0;
	int lastDigit = 0;

	if (numDigits <= 1)
		return true;

	firstDigit = input / (int)pow(10, numDigits - 1);
	lastDigit = input % 10;

	if (firstDigit != lastDigit)
		return false;

	return isPalindromeFunction(input % (int)pow(10, numDigits - 1) / 10, numDigits - 2);
}
	//pow = have to type cast to int(ambiguity) "10 to the power of numDigts - 1" 
//****************************************************************************************************