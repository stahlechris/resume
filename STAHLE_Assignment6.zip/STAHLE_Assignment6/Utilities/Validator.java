//***************************************************************************
//	File:                       ValidatorTest.Java
//
//	Student:                    Chris Stahle
//
//	Assignment:                 Program  # 6
//
//	Course Name:                Java Programming I
//
//	Course Number:              COSC 2050 - 01
//
//      Due:                        October 4, 2016
//
//      Description:                This program uses a GUI + SwingValidator
//                                  class to gather and validate user input. 
//***************************************************************************
package Utilities;

import javax.swing.*;
import javax.swing.text.JTextComponent;

public class Validator 
{
    public boolean isPresent(JTextComponent c,String fieldName) 
    {
        if (c.getText().length() == 0) 
        {
            showMessage(c, fieldName + " is a required field.");
            c.requestFocusInWindow();
            return false;
        }
        return true;
    }

    public boolean isInteger(JTextComponent c,String fieldName) 
    {
        try 
        {
            int i = Integer.parseInt(c.getText());
            return true; //else do the code below              
        } 
        catch (NumberFormatException e) 
        {
            showMessage(c, fieldName + " must be an integer from 0-120.");
            c.requestFocusInWindow();
            return false;
        }
        
    }
    public boolean isInRange(JTextComponent c, String fieldName)
    {
        int i = Integer.parseInt(c.getText()); //already know its an int, so ok
        if ((i < 0) || (i > 120)) 
        {
            showMessage(c, fieldName + " must be an integer from 0-120.");
            c.requestFocusInWindow();
            return false;
        }
        return true;
    }
    public boolean isDouble(JTextComponent c,String fieldName) 
    {
        try 
        {
            double d = Double.parseDouble(c.getText());
            return true;
        } 
        catch (NumberFormatException e) 
        {
            showMessage(c, fieldName + " must be a valid number.");
            c.requestFocusInWindow();
            return false;
        }
    }

    private void showMessage(JTextComponent c,String message) 
    {
        JOptionPane.showMessageDialog(c, message,"Invalid Entry", 
                                      JOptionPane.ERROR_MESSAGE);
    }
   

}//end package 
