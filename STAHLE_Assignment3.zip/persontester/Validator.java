//***************************************************************************
//	File:                       PersonTester.Java
//
//	Student:                    Chris Stahle
//
//	Assignment:                 Program  # 3
//
//	Course Name:                Java Programming I
//
//	Course Number:              COSC 2050 - 01
//
//      Due:                        September 13, 2016
//
//      Description:                This program utilizes classes + inheritance  
//                                  to store customer / employee data.  
//                                  
//***************************************************************************
package persontester;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validator 
{

    public static String getUserChoice(Scanner sc, String prompt, String error) 
    {
        String choice = "";
        boolean isValid = false;
        while (!isValid) 
        {
            System.out.print(prompt);
            choice = sc.next();
            if(prompt.equals("Continue? (y/n): ")) //if y/n then do this test
            {
                if (!choice.equalsIgnoreCase("y") 
                && !choice.equalsIgnoreCase("n") )
                {
                    System.out.print(error);
                } 
                 else 
                {
                    isValid = true;
                    break;
                }
            }
            else if(prompt.equals("Create customer or employee? (c/e): "))
            {
                if (!choice.equalsIgnoreCase("c") 
                && !choice.equalsIgnoreCase("e") )
                {
                    System.out.print(error);
                } 
                 else 
                {
                    isValid = true;
                    break;
                }
            }
        } 
        return choice;
    }
////////////////////////////////////////////////////////////////////////////////
    public static String getName(Scanner sc, String prompt, String error) 
    {
        String name = "";
        String REGIX = "^\\pL+[\\pL\\pZ\\pP]{0,}$"; //compensate for many names
        //http://stackoverflow.com/questions
        ///15805555/java-regex-to-validate-full-name-allow-only-spaces-and-letters
        boolean isValid = false;
        while (!isValid) 
        {
            System.out.print(prompt);
            name = sc.next();
            Pattern pattern = Pattern.compile(REGIX);
            Matcher matcher = pattern.matcher(name);
            if (name.isEmpty() || !matcher.matches() ) //fn.length() < 1
            {
                System.out.print(error +"\n");
            } 
            else 
            {
                isValid = true;
                break;
            }
        }
        return name;
    }
////////////////////////////////////////////////////////////////////////////////    
    public static String getEmail(Scanner sc) 
    {
        String em = "";
        boolean isValid = false;
        while (!isValid) 
        {
            System.out.print("Enter email address: ");
            em = sc.next();
            String EMAIL_REGIX = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]{0,10})"
                    + "*@[A-Za-z0-9]+(\\.[A-Za-z0-9]{0,10})*(\\.[A-Za-z]{0,5})$";
            Pattern pattern = Pattern.compile(EMAIL_REGIX);
            Matcher matcher = pattern.matcher(em);
            //https://docs.oracle.com/javase/7/docs/api/java/util/regex/Matcher.html
            //please include regix-creating in lecture!!
            if (matcher.matches()) 
            {
                isValid = true;
                break;
            } 
            else 
            {
                System.out.print("Error! Enter a valid email address!\n");
            }
        }
        return em;
    }
////////////////////////////////////////////////////////////////////////////////     
    public static String getCustomerNum(Scanner sc) 
    {
        boolean isValid = false;
        String cn = "";
        while (!isValid) 
        {
            System.out.print("Enter customer number: "
                    + "Example:'X00000'\t ");
            cn = sc.next();
            Pattern pattern = Pattern.compile("\\w{1}\\d{5}");
            Matcher matcher = pattern.matcher(cn);
            if (matcher.matches()) 
            {
                isValid = true;
                break;
            } 
            else 
            {
                System.out.print("Error! Enter a valid customer num.\n"
                        + "Example:X00000 \n");
            }
        }
        return cn;
    }
////////////////////////////////////////////////////////////////////////////////    
    public static String getSsn(Scanner sc) 
    {
        boolean isValid = false;
        String ssn = "";
        while (!isValid) 
        {
            System.out.print("Enter social security number: "
                    + "Example:'000-00-0000'\t");
            ssn = sc.next();
            Pattern pattern = Pattern.compile("\\d{3}-\\d{2}-\\d{4}");
            Matcher matcher = pattern.matcher(ssn);
            if (matcher.matches()) 
            {
                isValid = true;
                break;
            } 
            else 
            {
                System.out.print("Error! Enter a valid social security number."
                        + "\nExample:000-00-0000 \n");
            }
        }
        return ssn;
    }
} //end package