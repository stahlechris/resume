//***************************************************************************
//	File:                       PersonTester.Java
//
//	Student:                    Chris Stahle
//
//	Assignment:                 Program  # 3
//
//	Course Name:                Java Programming I
//
//	Course Number:              COSC 2050 - 01
//
//      Due:                        September 13, 2016
//
//      Description:                This program utilizes classes + inheritance  
//                                  to store customer / employee data.  
//                                  
//***************************************************************************
package persontester;

import java.util.Scanner;

public class PersonTester 
{
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
        String userChoice = "y"; 
        String CorE = ""; //customer OR employee
        Boolean isValid = false; 
        
        System.out.print("Welcome to the Person Tester application\n");
        while (userChoice.equalsIgnoreCase("y")) 
        {
            CorE = Validator.getUserChoice(sc, "Create customer or employee? (c/e): "
                                            , "Error! Must enter 'c' or 'e'\n"); 
            if(CorE.equalsIgnoreCase("c"))
            {
                Customer c = new Customer(); //make a new customer
                System.out.print("You made a new customer!\n"); 
                c.setFirstName(Validator.getName(sc, "Enter first name: "
                                    ,"Error! Must enter a first name.\n"));
                c.setLastName(Validator.getName(sc, "Enter last name: "
                                    ,"Error! Must enter a last name.\n"));
                c.setEmail(Validator.getEmail(sc));
                c.setCustomerNum(Validator.getCustomerNum(sc));
                System.out.print("\nYou entered:\n");
                System.out.print(c.getDisplayText()+ "\n"); 
            }
            else
            {
                Employee e = new Employee(); //make a new employee
                System.out.print("You made a new employee!\n"); 
                e.setFirstName(Validator.getName(sc, "Enter first name: "
                                    ,"Error! Must enter a first name.\n"));
                e.setLastName(Validator.getName(sc, "Enter last name: "
                                    ,"Error! Must enter a last name.\n"));
                e.setEmail(Validator.getEmail(sc));
                e.setSsn(Validator.getSsn(sc));
                System.out.print("\nYou entered:\n");
                System.out.print(e.getDisplayText()+"\n");
            }
            userChoice = Validator.getUserChoice(sc, "Continue? (y/n): "
                       , "Error! Must enter either 'y' or 'n'. \n"); 
        } 
            System.out.print("Goodbye\n");
    }   
}