//***************************************************************************
//	File:                       PersonTester.Java
//
//	Student:                    Chris Stahle
//
//	Assignment:                 Program  # 3
//
//	Course Name:                Java Programming I
//
//	Course Number:              COSC 2050 - 01
//
//      Due:                        September 13, 2016
//
//      Description:                This program utilizes classes + inheritance 
//                                  to store customer / employee data.  
//                                  
//***************************************************************************
package persontester;

public abstract class Person 
{
    private String firstName;
    private String lastName;
    private String email;

    Person() 
    {
        firstName = "";
        lastName = "";
        email = "";
        //or this("", "", "");
    }

    public abstract String getDisplayText();

    public String toString() 
    {
        return "Name: " + firstName + " " + lastName + "\n"
                + "Email: " + email + "\n";
    }

    public String getFirstName() 
    {
        return firstName;
    }

    public String getLastName() 
    {
        return lastName;
    }

    public String getEmail() 
    {
        return email;
    }

    public void setFirstName(String fn) 
    {
        firstName = fn;
    }

    public void setLastName(String ln) 
    {
        lastName = ln;
    }

    public void setEmail(String e) 
    {
        email = e;
    }

}