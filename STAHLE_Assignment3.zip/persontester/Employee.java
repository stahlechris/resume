//***************************************************************************
//	File:                       PersonTester.Java
//
//	Student:                    Chris Stahle
//
//	Assignment:                 Program  # 3
//
//	Course Name:                Java Programming I
//
//	Course Number:              COSC 2050 - 01
//
//      Due:                        September 13, 2016
//
//      Description:                This program utilizes classes + inheritance
//                                  to store customer / employee data.  
//                                  
//***************************************************************************
package persontester;

public class Employee extends Person 
{

    private String ssn;

    Employee() 
    {
        ssn = "";
    }

    @Override
    public String getDisplayText() 
    {
        return super.toString()
                + "Social security number: " + ssn + "\n";
    }

    public String getSsnNum() 
    {
        return ssn;
    }

    public void setSsn(String ssn) 
    {
        this.ssn = ssn;
    }

}
