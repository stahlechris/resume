//***************************************************************************
//	File:                       ReservationCalculator.Java
//
//	Student:                    Chris Stahle
//
//	Assignment:                 Program  # 4
//
//	Course Name:                Java Programming I
//
//	Course Number:              COSC 2050 - 01
//
//      Due:                        September 20, 2016
//
//      Description:                This program allows users to calculate 
//                                  their price for a hotel based on 
//                                  arival + departure time. 
//***************************************************************************
package reservationcalculator;

import java.math.BigDecimal;
import java.util.Scanner;
import java.util.Date;

public class ReservationCalculator 
{
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
        String userChoice = "y";
        System.out.print("Welcome to the Reservation Calculator.\n");
        while (userChoice.equalsIgnoreCase("y")) 
        {
            boolean isValid = false;
            while(!isValid)
            {
                Reservation r = new Reservation();//make a reservation object 
                r.setArrivalDate(Validator.getArrivalDate(sc, "Enter the arrival "
                   , "Error! Must be an integer within range.\n"
                   , "Error! no time travelling allowed!\n"
                   , "Error! That's not even an int??\n")); //supply prompts
                
                Date updatedArrivalDate = r.getArrivalDate();//need to validate departure dates
                
                r.setDepartureDate(Validator.getDepartureDate(sc, "Enter the departure "
                   , "Error! Must be an integer within range.\n"
                   , "Error! no time travelling allowed!\n"
                   , "Error! That's not even an int??\n", updatedArrivalDate));
                r.numDays();
                r.calculateTotalPrice(BigDecimal.ONE);//practice with BigDecimal
                System.out.print(r.getDisplayText());//format and fix results 
                isValid = true;
            }//we are not storing past results yet in any data structures..
            userChoice = Validator.getUserChoice(sc, "Another reservation? (y/n): "
                       , "Error! Must enter 'y' or 'n'\n");
        }
        System.out.print("Goodbye.\n");
    }
}