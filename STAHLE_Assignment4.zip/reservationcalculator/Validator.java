//***************************************************************************
//	File:                       ReservationCalculator.Java
//
//	Student:                    Chris Stahle
//
//	Assignment:                 Program  # 4
//
//	Course Name:                Java Programming I
//
//	Course Number:              COSC 2050 - 01
//
//      Due:                        September 20, 2016
//
//      Description:                This program allows users to calculate 
//                                  their price for a hotel based on 
//                                  arival + departure time. 
//***************************************************************************
package reservationcalculator;

import java.text.SimpleDateFormat;
import java.time.*;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Scanner;

public class Validator 
{

    public static String getUserChoice(Scanner sc, String prompt, String error) 
    {
        String choice = "";
        boolean isValid = false;
        while (!isValid) 
        {
            System.out.print(prompt);
            choice = sc.next();
            if (prompt.equals("Another reservation? (y/n): ")) 
            {
                if (!choice.equalsIgnoreCase("y")
                        && !choice.equalsIgnoreCase("n")) 
                {
                    System.out.print(error);
                } 
                else 
                {
                    isValid = true;
                    break;
                }
            }
        }
        return choice;
    }
//////////////////////////////////////////////////////////////////////////////// 
    public static Date getArrivalDate(Scanner sc, String arrivalPrompt,
            String errorMsgGeneric, String errorMsgTimeTravel
            , String errorMsgNotInt) 
    {
        Calendar calendar = Calendar.getInstance();//use old java calendar
        SimpleDateFormat dateFormat = new SimpleDateFormat("EEEEE");//format symbols
        
        Date date = new Date(); //use new java 1.8 
        LocalDate localDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        
        System.out.print("Current date is: "+calendar.getTime().toString()+"\n\n");
        
        boolean isValid = false;
        boolean isValid1 = false;
        boolean isValid2 = false;
        int year = 0;
        int month = 0;
        int day = 0;
        int i = 0; //iterator
        String prompt[] = {"year (2016+):", "month (1-12):", "day (1-31):",};
        while (!isValid) //!!year has to go first to determine number of days in certain month
        {
            System.out.print(arrivalPrompt + prompt[i]);
            if (sc.hasNextInt()) //if they type an int...
            {
                year = sc.nextInt(); //we get an int
                if ((year < localDate.getYear())) //we test it against current year
                {
                    System.out.print(errorMsgTimeTravel);
                } 
                else if ((year > 3000)) //we (arbitrarily)limit the input range 
                {
                    System.out.print(errorMsgGeneric); //out of bounds 
                } 
                else 
                {
                    System.out.print("You chose " + year + "\n");
                    i++; //increment to next prompt
                    isValid = true; //go to month validation
                }
            } 
            else //user did not enter an int 
            {
                System.out.print(errorMsgNotInt); 
                sc.next(); //clear it, try again
            }
        }//year is done 
////////////////////////////////////////////////////////////////////////////////        
        while (!isValid1) 
        {
            System.out.print(arrivalPrompt + prompt[i]); //"enter the arrival+ month"
            if (sc.hasNextInt()) 
            {
                month = sc.nextInt();
//http://stackoverflow.com/questions/7182996/java-get-month-integer-from-date
                if(month < localDate.getMonthValue())//better to use java time class!
                {
                    System.out.print(errorMsgTimeTravel);//attempting to book a month that already occured this year
                } 
                else if (month >= 13)//bc month<=0 always displays timetravelerrormsg
                {
                    System.out.print(errorMsgGeneric);
                } 
                else 
                {
                    System.out.print("You chose " + Month.of(month).name() + "\n");//requires 1.8java
                    i++; //increment prompt(now 1)
                    isValid1 = true;
                }
            } 
            else //user did not enter an int 
            {
                System.out.print(errorMsgNotInt); 
                sc.next();  
            }
        } //month is done 
////////////////////////////////////////////////////////////////////////////////   
        while (!isValid2) 
        {
            System.out.print(arrivalPrompt + prompt[i]); //"enter the arrival+ day"
            if (sc.hasNextInt()) 
            {
                day = sc.nextInt(); //we got an int
                YearMonth ym = YearMonth.of(year, month);
//http://docs.oracle.com/javase/8/docs/api/java/time/YearMonth.html                
                int daysInMonth = ym.lengthOfMonth(); //X days in X month based on X year
                
                if ( month == localDate.getMonthValue() )//if input month == current month, test to see if they are choosing a previous day 
                {
                    if(day < localDate.getDayOfMonth())
                    {
                        System.out.print(errorMsgTimeTravel);
                    }
                    else
                    {
                        Date arrivalDateTemp = new GregorianCalendar(year, month-1, day).getTime();
                        String nameOfDay = dateFormat.format(arrivalDateTemp);
                        System.out.print("You chose " + nameOfDay + "\n");
                        i--;
                        i--;//reset the prompt to avoid out of bounds exception!
                        isValid2 = true; //!this block of code has to be copied here for if they hit the errorMsgTimeTravel 
                    }
                } 
                else if (day > daysInMonth)//Example: THERES NOT 31 DAYS IN FEBRUARY!
                {
                    System.out.print(errorMsgGeneric); //out of bounds due to numdays in X month 
                    System.out.print("There are "+ daysInMonth + " days in that month!\n");
                } 
                else //days are 1-7 in java
                {
                    Date arrivalDateTemp = new GregorianCalendar(year, month-1, day).getTime();
                    String nameOfDay = dateFormat.format(arrivalDateTemp);
                    System.out.print("You chose " + nameOfDay + "\n");
                    i--;
                    i--;//reset the prompt to avoid out of bounds exception!
                    isValid2 = true;
                }
            }
            else //u did not enter an int
            {
                System.out.print(errorMsgNotInt); 
                sc.next(); //clear it 
            }
        }//do above variables drop out of memory when return hit in Java, or memory leak?
        Date arrivalDate = new GregorianCalendar(year, month - 1, day).getTime();
        return arrivalDate;
    }///end of method
////////////////////////////////////////////////////////////////////////////////
    public static Date getDepartureDate(Scanner sc, String departurePrompt
            , String errorMsgGeneric, String errorMsgTimeTravel
            , String errorMsgNotInt, Date updatedArrivalDate) 
    {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("EEEEE");
        
        LocalDate localArrivalDate = updatedArrivalDate.toInstant()
                  .atZone(ZoneId.systemDefault()).toLocalDate();//allows me to pull yr/mon/day
//http://stackoverflow.com/questions/9474121
///i-want-to-get-year-month-day-etc-from-java-date-to-compare-with-gregorian-calen       
        boolean isValid = false;
        boolean isValid1 = false;
        boolean isValid2 = false;
        int year = 0;
        int arrivalYear = localArrivalDate.getYear();
        int month = 0;
        int arrivalMonth = localArrivalDate.getMonthValue(); //returns 1-12
        int day = 0;
        int arrivalDay = localArrivalDate.getDayOfMonth();
        String prompt[] = {"year (2016+):", "month (1-12):", "day (1-31):",};
        int i = 0; //iterator
        while (!isValid) //!!year has to go first to determine number of days in certain month!!!
        {
            System.out.print(departurePrompt + prompt[i]);
            if (sc.hasNextInt()) 
            {
                year = sc.nextInt(); 
                if (!(year >= calendar.get(Calendar.YEAR)) 
                    || (year < arrivalYear )) //doesn't make sense to depart before you have arrived..
                {
                    System.out.print(errorMsgTimeTravel);
                } 
                else if ((year > 3000)) 
                {
                    System.out.print(errorMsgGeneric); //out of bounds 
                } 
                else 
                {
                    System.out.print("You chose " + year + "\n");
                    i++; //increment to next prompt
                    isValid = true; //go to month 
                }
            } 
            else //user did not enter an int 
            {
                System.out.print(errorMsgNotInt); //not even an int =(((
                sc.next(); //clear it 
            }
        }//year is done 
////////////////////////////////////////////////////////////////////////////////        
        while (!isValid1) 
        {
            System.out.print(departurePrompt + prompt[i]); //"enter the arrival+ month"
            if (sc.hasNextInt()) 
            {
                month = sc.nextInt();
                if ( year == arrivalYear && month < arrivalMonth) //cant depart before we arrive 
                {
                    System.out.print(errorMsgTimeTravel);//before the current date
                } 
                else if (month >= 13) //out of bounds 
                {
                    System.out.print(errorMsgGeneric);
                } 
                else //months are 0 based before java 1.8
                {
                    System.out.print("You chose " + Month.of(month).name() + "\n");//requires 1.8java
                    i++; //increment prompt(now 1)
                    isValid1 = true;
                }
            } 
            else //use did not enter an int 
            {
                System.out.print(errorMsgNotInt); //do u even int bro
                sc.next(); //clear it 
            }
        } //month is done 
////////////////////////////////////////////////////////////////////////////////   
        while (!isValid2) 
        {
            System.out.print(departurePrompt + prompt[i]); //"enter the arrival+ day"
            if (sc.hasNextInt()) 
            {
                day = sc.nextInt(); //we got an int
                YearMonth ym = YearMonth.of(year, month);
//http://docs.oracle.com/javase/8/docs/api/java/time/YearMonth.html                
                int daysInMonth = ym.lengthOfMonth(); //X days in X month based on X year
               
                if(year == arrivalYear && month==arrivalMonth)//if departing month == to arriving month, check to see not previous day 
                {
                    if (day < arrivalDay) //cant depart before we arrive  
                    {
                        System.out.print(errorMsgTimeTravel); 
                    } 
                    else
                    {
                        Date arrivalDateTemp = new GregorianCalendar(year, month-1, day).getTime();
                        String nameOfDay = dateFormat.format(arrivalDateTemp);
                        System.out.print("You chose " + nameOfDay + "\n");
                        i--;
                        i--;//reset the prompt to avoid out of bounds exception!
                        isValid2 = true;
                    }
                }
                else if (day > daysInMonth)//Example: THERES NOT 31 DAYS IN FEBRUARY!
                {
                    System.out.print(errorMsgGeneric); //out a bounds due to numdays in X month 
                    System.out.print("There are "+ daysInMonth + " days in that month!\n");
                } 
                else //days are 1-7 in java
                {
                    Date arrivalDateTemp = new GregorianCalendar(year, month-1, day).getTime();
                    String nameOfDay = dateFormat.format(arrivalDateTemp);
                    System.out.print("You chose " + nameOfDay + "\n");
                    i--;
                    i--;//reset the prompt to avoid out of bounds exception!
                    isValid2 = true;
                }
            } 
            else //u did not enter an int
            {
                System.out.print(errorMsgNotInt); 
                sc.next(); //clear it 
            }
        }
        Date departureDate = new GregorianCalendar(year, month - 1, day).getTime();
        return departureDate;
    }///end of method
////////////////////////////////////////////////////////////////////////////////
} //end of class. I had fun researching the old calendar and Date and the new java 1.8 classes
//i wanted to show I am capable of using both, so i incorporated both. 