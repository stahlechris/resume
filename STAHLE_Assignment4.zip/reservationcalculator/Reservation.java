//***************************************************************************
//	File:                       ReservationCalculator.Java
//
//	Student:                    Chris Stahle
//
//	Assignment:                 Program  # 4
//
//	Course Name:                Java Programming I
//
//	Course Number:              COSC 2050 - 01
//
//      Due:                        September 20, 2016
//
//      Description:                This program allows users to calculate 
//                                  their price for a hotel based on 
//                                  arival + departure time. 
//***************************************************************************
package reservationcalculator;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.Date;
import java.text.SimpleDateFormat;

public class Reservation 
{
    private Date arrivalDate;
    private Date departureDate;
    private final double NIGHTLY_RATE = 115.00;
    private int numDays = 0;
    private BigDecimal price;
    final int MILLS_IN_DAY = 24*60*60*1000;
    
    Reservation()
    {
        
    }

    public void setArrivalDate(Date sad)
    {
        arrivalDate = sad;
    }
    public Date getArrivalDate()
    {
        return arrivalDate;
    }
    public void setDepartureDate(Date sdd)
    {
        departureDate = sdd;
    }
    public String getDisplayText()
    {
        SimpleDateFormat outputFormat = new SimpleDateFormat("EEEE, MMMM d, YYYY");
        NumberFormat currency = NumberFormat.getCurrencyInstance();

        return "\nArrival Date: " + outputFormat.format(arrivalDate) + "\n"
        +      "Departure Date: " + outputFormat.format(departureDate) + "\n"
        +      "Price: " + NIGHTLY_RATE + " per night\n"
        +       "Total Price: " + currency.format(price)+" for "+numDays+" nights\n\n";
    }
    //https://docs.oracle.com/javase/7/docs/api/java/text/SimpleDateFormat.html
    public int numDays() //arival date - departure date 
    {
        long difference = departureDate.getTime() - arrivalDate.getTime();
        return  numDays = (int) (difference / MILLS_IN_DAY);
    }
    public BigDecimal calculateTotalPrice(BigDecimal Price)
    {
        BigDecimal rate = new BigDecimal(Double.toString(NIGHTLY_RATE));
        return price = rate.multiply(new BigDecimal(numDays));
    }
}