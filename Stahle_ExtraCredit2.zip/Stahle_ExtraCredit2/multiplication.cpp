//****************************************************************************************************
//
//		File:					NumericPalindrome.cpp
//
//		Student:				Chris Stahle
//
//		Assignment:	 			Program  # Extra Credit 1
//
//		Course Name:			Data Structures II
//
//		Course Number:			COSC 3050 - 01
//
//		Due:					May 5, 2016
//
//
//		This program uses a recursive function to determine the product of a number times an integer
//		value.
//
//****************************************************************************************************
#include <iostream>
using namespace std;
//****************************************************************************************************
double multiply(double number, int multiplier);
//****************************************************************************************************
int main()
{
	double number = 1; 
	double product = 0;
	int multiplier = 1;

	cout << "Enter a number to multiply(0 to quit): ";
	cin >> number;

	cout << "Enter a multiplier(0 to quit): ";
	cin >> multiplier;

	while(number, multiplier)
	{
		product = multiply(number, multiplier);

		cout << "The product is: " << product << endl;

		cout << "Enter a number to multiply(0 to quit): ";
		cin >> number;

		cout << "Enter a multiplier(0 to quit): ";
		cin >> multiplier;
	}
}
//****************************************************************************************************
double multiply(double number, int multiplier)
{
	if (multiplier == 0)
	{
		return 0;
	}
	else
	{
		return number + multiply(number, multiplier - 1);
	}
}
//****************************************************************************************************